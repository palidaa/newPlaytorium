<template>
</template>

<script>
  export default {
    mounted() {
      console.log('mounted');
    }
  }
</script>
